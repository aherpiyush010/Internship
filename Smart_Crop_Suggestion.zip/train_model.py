import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
import joblib

# Load dataset
df = pd.read_csv('data.csv')

# Encode categorical columns
le_soil = LabelEncoder()
le_season = LabelEncoder()
le_crop = LabelEncoder()

df['soil_type'] = le_soil.fit_transform(df['soil_type'])
df['season'] = le_season.fit_transform(df['season'])
df['crop'] = le_crop.fit_transform(df['crop'])

# Features and target
X = df[['temperature', 'humidity', 'soil_type', 'season']]
y = df['crop']

# Train model
model = DecisionTreeClassifier()
model.fit(X, y)

# Save model and encoders
joblib.dump(model, 'crop_model.pkl')
joblib.dump(le_soil, 'soil_encoder.pkl')
joblib.dump(le_season, 'season_encoder.pkl')
joblib.dump(le_crop, 'crop_encoder.pkl')
