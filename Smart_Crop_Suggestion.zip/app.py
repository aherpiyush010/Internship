from flask import Flask, request, render_template
import joblib
import numpy as np

app = Flask(__name__)

# Load model and encoders
model = joblib.load('crop_model.pkl')
soil_enc = joblib.load('soil_encoder.pkl')
season_enc = joblib.load('season_encoder.pkl')
crop_enc = joblib.load('crop_encoder.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    temp = float(request.form['temperature'])
    humidity = float(request.form['humidity'])
    soil = soil_enc.transform([request.form['soil_type']])[0]
    season = season_enc.transform([request.form['season']])[0]

    data = np.array([[temp, humidity, soil, season]])
    pred = model.predict(data)
    crop_name = crop_enc.inverse_transform(pred)[0]

    return render_template('index.html', prediction=f"Suggested Crop: {crop_name}")

if __name__ == '__main__':
    app.run(debug=True)
